BiblePro Plugin
---------------

To install this BiblePro Plugin simply unzip it with WINZIP or PKUNZIP
into the same directory as BiblePro (Usually c:\biblepro)

You need to have BiblePro on your system. 
Get your copy from http://www.icis.on.ca/bible

Enjoy,
BiblePro Authors

